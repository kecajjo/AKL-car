.. ivPID documentation master file, created by
   sphinx-quickstart on Fri Dec 18 12:30:42 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ivPID Ivmech Python PID Controller
=================================

.. figure:: images/pid_control.png
   :align:   center

   PID Controller


.. toctree::
   :maxdepth: 2

.. automodule:: PID

.. autoclass:: PID
    :members:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

